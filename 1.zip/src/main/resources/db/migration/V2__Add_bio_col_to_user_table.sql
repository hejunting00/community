alter table USER add bio varchar(256) null;
