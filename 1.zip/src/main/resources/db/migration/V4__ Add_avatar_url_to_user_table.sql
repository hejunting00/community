alter table USER
    add avatar_url varchar(100);
